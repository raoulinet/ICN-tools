<div class="table-wrapper">
    <table class="git-description" cellpadding="0" cellspacing="0">
        <tr><td>description</td><td><?php echo $description; ?></td></tr>
        <tr><td>owner</td><td><?php echo $owner; ?></td></tr>
        <tr><td>last change</td><td><?php echo $last_change; ?></td></tr>
    </table>
</div>