<?php
require 'web' . DIRECTORY_SEPARATOR . 'index.php';
